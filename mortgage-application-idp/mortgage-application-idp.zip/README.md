# Mortgage Application Document Check

Upload a mortgage application package and let the process sort it, read it, and check it. Each
document is classified, its data is extracted, and the package is checked for missing documents and
for data that doesn't add up. Clean applications go straight to underwriting. Everything else goes to
a reviewer with the reasons listed.

This example uses [Intelligent Document Processing (IDP)](https://docs.camunda.io/docs/next/components/hub/workspace/modeler/idp/)
classification and unstructured extraction, and requires **Camunda 8.11.0-alpha2+**.

## How the process works

1. **Mortgage application received.** The start form collects the applicant's name, the loan amount,
   the property postcode, and the application documents as PDFs.
2. **Process each document.** For every uploaded file, in parallel:
   - **Classify document** decides whether it is an identity document, pay stub, bank statement,
     employment letter, or property valuation.
   - If the model is unsure, **Confirm document type** asks a person to pick the type.
   - One of five **Extract …** tasks reads the fields for that document type.
3. **Check documents complete** (DMN) lists any required document types that are missing.
   **Request missing documents** asks for them, and the new files go through step 2.
4. **Compare documents** checks the documents against each other. For example, it checks that the
   names match the ID, the ID has not expired, net pay matches the salary on the bank statement, and
   the valuation is for the right property.
5. **Find application issues** (DMN) turns failed checks into a list of issues.
6. No issues: **Hand over to underwriting**. Issues: **Review application** shows them to a
   reviewer, who approves, asks for more documents, or rejects.

**Hand over to underwriting** is a placeholder. Replace it with a call to your own loan system.

## 🚀 Zero-config LLM on Camunda SaaS

The IDP tasks are set up for the **Camunda-provided LLM**. You do not need your own LLM credentials.
Check [access and budget requirements](https://docs.camunda.io/docs/components/agentic-orchestration/camunda-provided-llm/).
Each application package uses about two LLM calls per document. If the Camunda-provided LLM is not
available to you, follow [Use your own LLM provider](#use-your-own-llm-provider).

The IDP tasks give each document to the model itself (multimodal), so scanned and photographed
documents work too, and you don't need an OCR service. To use a separate text extraction service
instead, see [Customize the example](#customize-the-example).

1. Import the [Mortgage Application Document Check from Marketplace](https://marketplace.camunda.com/en-US/apps/TODO)
   into Camunda Hub.
2. Download the [sample documents](./sample-documents/).
3. Open the diagram, then open **Test mode**.
4. Deploy and start the process. In the start form, enter the applicant data from
   [`sample-documents/happy-path/applicant.json`](./sample-documents/happy-path/applicant.json) and
   upload the five PDFs from `sample-documents/happy-path/`.
5. Watch the instance in Test mode. It should end in **Ready for underwriting** without any user task.

Then try the other sample sets:

| Folder | What happens |
|---|---|
| `happy-path/` | All checks pass. Ends in **Ready for underwriting** |
| `needs-review/` | Net pay doesn't match the salary deposit, and the employment is fixed-term. Opens **Review application** with two issues |
| `incomplete/` | The bank statement is missing. Opens **Request missing documents**. Upload `happy-path/bank-statement.pdf` to continue |

The sample documents are fictional. They describe a made-up applicant, employer, bank, and valuer.

> The checks compare dates with today. The sample documents have fixed dates, so after a while the
> pay stub counts as too old and the run opens **Review application** with `PAY_STUB_OLD`. To avoid
> that, start the process with the variable `checkDate` set to the date in `applicant.json`.

Each sample folder also has an `expected.json` with the expected document type and extracted values
for every file. Use it to check the extraction prompts on the IDP test bench.

## Use your own LLM provider

Use this approach on SaaS without Camunda-provided LLM access, or on Self-Managed.

1. Open each of the six IDP tasks: **Classify document** and the five **Extract …** tasks.
2. Under **AI providers**, select your provider: Amazon Bedrock, Google Vertex AI, Azure AI Foundry,
   or any OpenAI-compatible endpoint. Follow the [IDP provider setup guide](https://docs.camunda.io/docs/next/components/hub/workspace/modeler/idp/idp-configuration/).
3. Add your provider credentials as secrets. On SaaS, use [cluster secrets](https://docs.camunda.io/docs/components/saas/clusters/manage-secrets/).
   On Self-Managed, [configure a secret store](https://docs.camunda.io/docs/self-managed/components/orchestration-cluster/core-settings/configuration/properties/#secrets)
   for the Orchestration Cluster.
4. Replace the `CAMUNDA_PROVIDED_LLM_*` references with your provider settings, and set the model in
   **AI converse parameters**.

Use the same provider and model in all six tasks. The extraction prompts are tuned together, and
**Compare documents** expects every task to follow the same output rules.

## Run it locally with Camunda 8 Run

This runs the full process locally. You need your own LLM provider and its credentials.

1. [Install Camunda 8 Run](https://docs.camunda.io/docs/self-managed/quickstart/developer-quickstart/c8run/install-start/)
   8.11.0-alpha2+.
2. Add your provider secrets to the
   [local secret store](https://docs.camunda.io/docs/self-managed/quickstart/developer-quickstart/c8run/configuration/#manage-local-secrets).
   For example, from the c8run directory:

   ```bash
   ./c8run secrets set OPENAI_API_KEY
   ```

   Enter the value at the hidden prompt. Do not put credentials in the BPMN.
3. Configure the six IDP tasks as described in [Use your own LLM provider](#use-your-own-llm-provider).
4. Start c8run using the instructions for your operating system.
5. Copy the six IDP template files (`Classify mortgage documents.json` and the five `Extract … .json`)
   into Desktop Modeler's [element templates folder](https://docs.camunda.io/docs/components/modeler/desktop-modeler/element-templates/configuring-templates/)
   and restart it. Then open the BPMN and deploy it to the local cluster together with both DMN files
   and the four forms.
6. Open Tasklist at `http://localhost:8080/tasklist`, start **Mortgage Application Document Check**,
   and fill in the start form as in the SaaS steps.
7. Use Operate at `http://localhost:8080/operate` to follow the instance and inspect any incidents.

## What gets extracted

Every IDP task uses the same rules. Dates are returned as `YYYY-MM-DD`. Amounts are returned as plain
numbers. Names are returned in upper case without titles or middle names. A value that isn't in the
document comes back as `null`.

| Document | Fields |
|---|---|
| Identity document | `fullName`, `dateOfBirth`, `idDocumentKind`, `documentNumber`, `issuingCountry`, `expiryDate` |
| Pay stub | `employeeName`, `employerName`, `payPeriodStart`, `payPeriodEnd`, `payDate`, `grossPay`, `netPay`, `currency` |
| Bank statement | `accountHolderName`, `bankName`, `statementPeriodStart`, `statementPeriodEnd`, `closingBalance`, `currency`, `salaryDeposits`, `returnedPayments` |
| Employment letter | `employeeName`, `employerName`, `jobTitle`, `employmentStartDate`, `contractType`, `probationEndDate`, `annualGrossSalary`, `letterDate` |
| Property valuation | `propertyAddress`, `propertyPostcode`, `valuationDate`, `marketValue`, `currency`, `valuerName`, `materialConcerns` |

Each field has its own prompt in the **Taxonomy items** of its **Extract …** task. The document types
and their descriptions are in **Document types** on **Classify document**.

## What gets checked

| Issue | When |
|---|---|
| `MISSING_FIELDS` | A required field could not be read |
| `NAME_MISMATCH` | The name differs between the ID, pay stub, bank statement, and employment letter |
| `APPLICANT_NOT_ID_HOLDER` | The name in the start form doesn't match the ID |
| `ID_EXPIRED` | The ID has expired |
| `PAY_STUB_OLD` | The latest pay stub is more than 60 days old |
| `NO_SALARY_DEPOSIT` | The bank statement shows no salary from the employer on the pay stub |
| `INCOME_MISMATCH` | Net pay and the salary deposit differ by more than 5% |
| `EMPLOYER_MISMATCH` | The pay stub and employment letter name different employers |
| `NOT_PERMANENT` | The employment is not permanent |
| `ON_PROBATION` | The applicant is still on probation |
| `RETURNED_PAYMENTS` | The bank statement shows returned or bounced payments |
| `PROPERTY_MISMATCH` | The valuation is for a different postcode |
| `HIGH_LTV` | The loan is more than 80% of the property value |
| `VALUATION_CONCERNS` | The valuer notes defects or risks |

The thresholds (60 days, 5%, 80%) and the list of required documents live in the two DMN tables.
Change them there, without touching the process.

These checks prepare an application for underwriting. They are not a credit decision, and they don't
verify the applicant's identity beyond the document data.

## Customize the example

- **Use a text extraction service.** In each IDP task, change **Text extraction provider** to the PDF
  text reader (PDFBox, for digital PDFs only), Amazon Textract, Google Document AI, Azure Document
  Intelligence, or ABBYY Vantage, and add that provider's secrets. Text extraction is cheaper and
  faster than sending each document to the model. See the [IDP connector reference](https://docs.camunda.io/docs/next/components/hub/workspace/modeler/idp/idp-reference/).
- **Use another AI provider.** See [Use your own LLM provider](#use-your-own-llm-provider).
- **Add a document type.** Add an entry to **Document types** on **Classify document**. Add a branch
  to the **Document type?** gateway with a new **Extract …** task, add a rule to
  `check-documents-complete.dmn`, and use the new fields in **Compare documents**.
- **Improve extraction.** Edit the prompts in **Taxonomy items**. Keep the format rules (dates,
  numbers, upper-case names), because **Compare documents** relies on them.
- **Tune the checks.** Edit `find-application-issues.dmn`.

Keep human review for any decision that affects the applicant. Model output can be wrong, and the
review form shows where every value came from.

Source and support: [camunda/camunda-8-tutorials](https://github.com/camunda/camunda-8-tutorials/tree/main/solutions/mortgage-application-document-check).

_Made with ❤️ by Camunda_
